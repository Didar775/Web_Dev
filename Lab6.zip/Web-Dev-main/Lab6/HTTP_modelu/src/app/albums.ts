export interface Albums {
  userId: number;
  id: number;
  title: string;
}
