let admin, name;

name = "John";

admin = name;

alert( admin );

// The variable for our planet
let ourPlanet = "Earth"
let userName = "Era"